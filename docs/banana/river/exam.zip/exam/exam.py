import numpy as np
import matplotlib.pyplot as plt
import river

plt.show()
