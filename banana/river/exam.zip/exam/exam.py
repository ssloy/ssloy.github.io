import numpy as np
import matplotlib.pyplot as plt
from river import current

vx, vy = current(.8, .8)
print(vx, vy)
plt.show()
